"""
Erstellt die Demo-Datenbank fuer das Lab.
Legt eine users-Tabelle und eine secrets-Tabelle an,
damit man den UNION-based Datenabfluss demonstrieren kann.

WICHTIG: Passwoerter stehen hier im Klartext, damit die
verwundbare Version simpel bleibt. In der sicheren Version
werden sie gehasht (siehe app_secure.py).
"""
import sqlite3
import os

DB_PATH = os.environ.get("DB_PATH", "/data/lab.db")


def build():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    cur.executescript(
        """
        DROP TABLE IF EXISTS users;
        DROP TABLE IF EXISTS secrets;

        CREATE TABLE users (
            id       INTEGER PRIMARY KEY,
            username TEXT NOT NULL,
            password TEXT NOT NULL
        );

        CREATE TABLE secrets (
            id     INTEGER PRIMARY KEY,
            label  TEXT NOT NULL,
            value  TEXT NOT NULL
        );
        """
    )

    users = [
        ("admin", "S3cr3t-Admin-Pw!"),
        ("alice", "password123"),
        ("bob", "hunter2"),
    ]
    cur.executemany("INSERT INTO users (username, password) VALUES (?, ?)", users)

    secrets = [
        ("api_key", "sk-DEMO-4f9a2c7b1e"),
        ("db_backup_location", "/backups/prod-2026-09.tar.gz"),
    ]
    cur.executemany("INSERT INTO secrets (label, value) VALUES (?, ?)", secrets)

    con.commit()
    con.close()
    print(f"[seed] Datenbank erstellt unter {DB_PATH}")


if __name__ == "__main__":
    build()
