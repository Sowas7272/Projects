"""
==========================================================
  SICHERE VERSION  --  der Fix
==========================================================
Zwei zentrale Verbesserungen gegenueber app_vulnerable.py:

1) Parameterisierte Queries (Prepared Statements):
   Nutzereingaben werden NIE in den SQL-String eingebaut,
   sondern als Parameter uebergeben (das '?'). Damit kann
   der Nutzer die Struktur der Query nicht mehr veraendern.

2) Passwort-Hashing mit bcrypt:
   Passwoerter werden nicht im Klartext verglichen, sondern
   gehasht gespeichert und geprueft.
"""
import sqlite3
import os
import bcrypt
from flask import Flask, request, render_template

app = Flask(__name__)
DB_PATH = os.environ.get("DB_PATH", "/data/lab_secure.db")


def get_db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def build_secure_db():
    """Eigene DB mit gehashten Passwoertern."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = get_db()
    con.executescript(
        """
        DROP TABLE IF EXISTS users;
        CREATE TABLE users (
            id       INTEGER PRIMARY KEY,
            username TEXT NOT NULL,
            pw_hash  TEXT NOT NULL
        );
        """
    )
    seed = [
        ("admin", "S3cr3t-Admin-Pw!"),
        ("alice", "password123"),
        ("bob", "hunter2"),
    ]
    for username, plain in seed:
        h = bcrypt.hashpw(plain.encode(), bcrypt.gensalt()).decode()
        con.execute(
            "INSERT INTO users (username, pw_hash) VALUES (?, ?)", (username, h)
        )
    con.commit()
    con.close()
    print(f"[secure] Datenbank mit gehashten Passwoertern erstellt: {DB_PATH}")


@app.route("/", methods=["GET"])
def index():
    return render_template("login.html", mode="SICHER", result=None, query=None)


@app.route("/login", methods=["POST"])
def login():
    user = request.form.get("username", "")
    pw = request.form.get("password", "")

    # >>> DER FIX: parameterisierte Query <<<
    # Der Platzhalter '?' trennt Code (SQL) sauber von Daten (Eingabe).
    query = "SELECT id, username, pw_hash FROM users WHERE username = ?"

    con = get_db()
    row = con.execute(query, (user,)).fetchone()
    con.close()

    ok = False
    if row is not None:
        ok = bcrypt.checkpw(pw.encode(), row["pw_hash"].encode())

    result = (
        f"Login OK -- eingeloggt als: {row['username']}"
        if ok
        else "Login fehlgeschlagen"
    )

    # Zeigt: dieselben Angriffe (admin'--, ' OR '1'='1) prallen ab.
    display_query = "SELECT ... WHERE username = ?   [Parameter: " + repr(user) + "]"
    return render_template(
        "login.html", mode="SICHER", result=result, query=display_query
    )


if __name__ == "__main__":
    build_secure_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
