"""
==========================================================
  VERWUNDBARE VERSION  --  NUR fuer das lokale Lab!
==========================================================
Diese App baut Nutzereingaben direkt in den SQL-String ein
(String-Konkatenation). Das ist die klassische SQL-Injection-
Schwachstelle. Niemals so in echten Anwendungen einsetzen.
"""
import sqlite3
import os
from flask import Flask, request, render_template

app = Flask(__name__)
DB_PATH = os.environ.get("DB_PATH", "/data/lab.db")


def get_db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


@app.route("/", methods=["GET"])
def index():
    return render_template("login.html", mode="VERWUNDBAR", result=None, query=None)


@app.route("/login", methods=["POST"])
def login():
    user = request.form.get("username", "")
    pw = request.form.get("password", "")

    # >>> DIE SCHWACHSTELLE <<<
    # Eingaben werden ungefiltert in den Query-String gebaut.
    query = (
        "SELECT id, username FROM users "
        f"WHERE username = '{user}' AND password = '{pw}'"
    )

    con = get_db()
    try:
        rows = con.execute(query).fetchall()
    except Exception as e:
        rows = []
        error = str(e)
    else:
        error = None
    finally:
        con.close()

    if rows:
        names = ", ".join(r["username"] for r in rows)
        result = f"Login OK -- eingeloggt als: {names} ({len(rows)} Treffer)"
    elif error:
        result = f"SQL-Fehler: {error}"
    else:
        result = "Login fehlgeschlagen"

    # Query wird bewusst mit angezeigt, damit man im Lab sieht,
    # was der Angreifer manipuliert hat.
    return render_template(
        "login.html", mode="VERWUNDBAR", result=result, query=query
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
