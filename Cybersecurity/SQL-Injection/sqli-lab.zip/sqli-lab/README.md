# SQL Injection Lab — von der Schwachstelle zum Fix

Ein kleines, bewusst verwundbares Login-System, das zeigt, **wie eine SQL-Injection
funktioniert** und **wie man sie mit einer einzigen Codeänderung stoppt**.

> ⚠️ **Nur für die lokale Lab-Umgebung.** Die verwundbare App ist absichtlich
> unsicher. Niemals öffentlich erreichbar machen und niemals gegen fremde Systeme
> testen — Angriffe nur gegen dieses eigene, lokale Lab.

## Was drin ist

| Version    | URL                     | Beschreibung                                |
|------------|-------------------------|---------------------------------------------|
| Verwundbar | http://localhost:5000   | Baut Eingaben direkt in den SQL-String ein  |
| Sicher     | http://localhost:5001   | Parameterisierte Query + bcrypt-Hashing     |

Stack: Python · Flask · SQLite · Docker

## Setup

Voraussetzung: Docker + Docker Compose (bei Omarchy über
*Super + Alt + Space → Install > Development > Docker*).

```bash
git clone <dein-repo-url> sqli-lab
cd sqli-lab
docker compose up --build
```

Danach im Browser öffnen:
- Verwundbar: <http://localhost:5000>
- Sicher: <http://localhost:5001>

## Die Schwachstelle

In `app_vulnerable.py` wird die Eingabe direkt zusammengeklebt:

```python
query = f"SELECT id, username FROM users WHERE username = '{user}' AND password = '{pw}'"
```

Der Nutzer kontrolliert damit nicht nur *Daten*, sondern die *Struktur* der Query.

## Angriffe zum Nachstellen

Alle in der **verwundbaren** Version (Port 5000):

**1. Auth-Bypass per Kommentar**
Username: `admin'--`  ·  Passwort: (beliebig)
→ Das `--` kommentiert die Passwortprüfung weg. Login als admin.

**2. Auth-Bypass ohne gültigen Namen**
Username: `' OR '1'='1' -- `  ·  Passwort: (beliebig)
→ Die Bedingung ist immer wahr, es matchen alle Nutzer.

**3. Datenabfluss (UNION-based)**
Username: `' UNION SELECT label, value FROM secrets -- `
→ Zieht Daten aus einer *anderen* Tabelle in das Ergebnis.

Die App zeigt jeweils die ausgeführte Query mit an, damit man genau sieht,
was manipuliert wurde.

## Der Fix

In `app_secure.py`:

```python
query = "SELECT id, username, pw_hash FROM users WHERE username = ?"
row = con.execute(query, (user,)).fetchone()
```

Der Platzhalter `?` trennt **Code von Daten**: Die Eingabe wird als reiner Wert
behandelt und kann die Query-Struktur nicht mehr verändern. Dieselben Angriffe
von oben prallen in der sicheren Version (Port 5001) ab.

## Defense in Depth

Prepared Statements sind die Hauptlösung. Zusätzlich in diesem Lab bzw. als
Best Practice:

- **Passwort-Hashing** mit bcrypt statt Klartext-Vergleich
- **Least Privilege** — der DB-Nutzer sollte nur die nötigen Rechte haben
- **Input-Validierung** als zusätzliche Schicht (nicht als Ersatz!)
- **Logging/Monitoring**, um Angriffsversuche zu erkennen

## Impact (was ein Angreifer real erreichen könnte)

- Anmeldung ohne gültige Zugangsdaten (Account-Übernahme)
- Auslesen fremder Tabellen (Datenabfluss, hier: API-Key, Backup-Pfad)
- Je nach Rechten: Verändern oder Löschen von Daten

## Projektstruktur

```
sqli-lab/
├── docker-compose.yml
├── README.md
└── app/
    ├── Dockerfile
    ├── requirements.txt
    ├── seed.py               # baut die Demo-DB
    ├── app_vulnerable.py     # die Schwachstelle
    ├── app_secure.py         # der Fix
    └── templates/
        └── login.html
```
